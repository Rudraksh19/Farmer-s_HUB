package com.cu.lab.example.aadesh1.hub;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class EditActivity extends AppCompatActivity {

    // creating variables for our edit text, firebase database,
    // database reference, course rv modal,progress bar.
    private TextInputEditText fNameEdt, fDescEdt, fPriceEdt, bestSuitedEdt, fImgEdt, flinkEdt;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    RVModal fRVModal;
    private ProgressBar loadingPB;
    // creating a string for our course id.
    private String fID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        // initializing all our variables on below line.
        setTitle("Edit Item");
        Button addfBtn = findViewById(R.id.idBtnAddf);
        fNameEdt = findViewById(R.id.idEdtfName);
        fDescEdt = findViewById(R.id.idEdtfDescription);
        fPriceEdt = findViewById(R.id.idEdtfPrice);
        bestSuitedEdt = findViewById(R.id.idEdtSuitedFor);
        fImgEdt = findViewById(R.id.idEdtfImageLink);
        flinkEdt = findViewById(R.id.idEdtfLink);
        loadingPB = findViewById(R.id.idPBLoading);
        firebaseDatabase = FirebaseDatabase.getInstance();
        // on below line we are getting our modal class on which we have passed.
        fRVModal = getIntent().getParcelableExtra("course");
        Button deletefBtn = findViewById(R.id.idBtnDeletef);

        if (fRVModal != null) {
            // on below line we are setting data to our edit text from our modal class.
            fNameEdt.setText(fRVModal.getfName());
            fPriceEdt.setText(fRVModal.getfPrice());
            bestSuitedEdt.setText(fRVModal.getBestSuitedFor());
            fImgEdt.setText(fRVModal.getfImg());
            flinkEdt.setText(fRVModal.getflink());
            fDescEdt.setText(fRVModal.getfDescription());
            fID = fRVModal.getfId();
        }

        // on below line we are initialing our database reference and we are adding a child as our course id.
        databaseReference = firebaseDatabase.getReference("User").child("Item").child(fID);
        // on below line we are adding click listener for our add course button.
        addfBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // on below line we are making our progress bar as visible.
                loadingPB.setVisibility(View.VISIBLE);
                // on below line we are getting data from our edit text.
                String fName = fNameEdt.getText().toString();
                String fDesc = fDescEdt.getText().toString();
                String fPrice = fPriceEdt.getText().toString();
                String bestSuited = bestSuitedEdt.getText().toString();
                String fImg = fImgEdt.getText().toString();
                String flink = flinkEdt.getText().toString();
                // on below line we are creating a map for
                // passing a data using key and value pair.
                Map<String, Object> map = new HashMap<>();
                map.put("fName", fName);
                map.put("fDescription", fDesc);
                map.put("fPrice", fPrice);
                map.put("bestSuitedFor", bestSuited);
                map.put("fImg", fImg);
                map.put("flink", flink);
                map.put("fId", fID);

                // on below line we are calling a database reference on
                // add value event listener and on data change method
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        // making progress bar visibility as gone.
                        loadingPB.setVisibility(View.GONE);
                        // adding a map to our database.
                        databaseReference.updateChildren(map);
                        // on below line we are displaying a toast message.
                        Toast.makeText(EditActivity.this, "Item Updated..", Toast.LENGTH_SHORT).show();
                        // opening a new activity after updating our coarse.
                        startActivity(new Intent(EditActivity.this, MainActivity.class));
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // displaying a failure message on toast.
                        Toast.makeText(EditActivity.this, "Fail to update Item..", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        // adding a click listener for our delete course button.
        deletefBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // calling a method to delete a course.
                deletef();
            }
        });

    }

    private void deletef() {
        // on below line calling a method to delete the course.
        databaseReference.removeValue();
        // displaying a toast message on below line.
        Toast.makeText(this, "Item Deleted..", Toast.LENGTH_SHORT).show();
        // opening a main activity on below line.
        startActivity(new Intent(EditActivity.this, MainActivity.class));
    }
}
