package com.cu.lab.example.aadesh1.hub;

import android.os.Parcel;
import android.os.Parcelable;

public class RVModal implements Parcelable {
    // creating variables for our different fields.
    private String fName;
    private String fDescription;
    private String fPrice;
    private String bestSuitedFor;
    private String fImg;
    private String flink;
    private String fId;


    public String getfId() {
        return fId;
    }

    public void setfId(String fId) {
        this.fId = fId;
    }


    // creating an empty constructor.
    public RVModal() {

    }

    protected RVModal(Parcel in) {
        fName = in.readString();
        fId = in.readString();
        fDescription = in.readString();
        fPrice = in.readString();
        bestSuitedFor = in.readString();
        fImg = in.readString();
        flink = in.readString();
    }

    public static final Creator<RVModal> CREATOR = new Creator<RVModal>() {
        @Override
        public RVModal createFromParcel(Parcel in) {
            return new RVModal(in);
        }

        @Override
        public RVModal[] newArray(int size) {
            return new RVModal[size];
        }
    };

    // creating getter and setter methods.
    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getfDescription() {
        return fDescription;
    }

    public void setfDescription(String fDescription) {
        this.fDescription = fDescription;
    }

    public String getfPrice() {
        return fPrice;
    }

    public void setfPrice(String fPrice) {
        this.fPrice = fPrice;
    }

    public String getBestSuitedFor() {
        return bestSuitedFor;
    }

    public void setBestSuitedFor(String bestSuitedFor) {
        this.bestSuitedFor = bestSuitedFor;
    }

    public String getfImg() {
        return fImg;
    }

    public void setfImg(String fImg) {
        this.fImg = fImg;
    }

    public String getflink() {
        return flink;
    }

    public void setflink(String flink) { this.flink = flink; }



    public RVModal(String fId, String fName, String fDescription, String fPrice, String bestSuitedFor, String fImg, String flink) {
        this.fName = fName;
        this.fId = fId;
        this.fDescription = fDescription;
        this.fPrice = fPrice;
        this.bestSuitedFor = bestSuitedFor;
        this.fImg = fImg;
        this.flink = flink;

    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(fName);
        dest.writeString(fId);
        dest.writeString(fDescription);
        dest.writeString(fPrice);
        dest.writeString(bestSuitedFor);
        dest.writeString(fImg);
        dest.writeString(flink);
    }
}
