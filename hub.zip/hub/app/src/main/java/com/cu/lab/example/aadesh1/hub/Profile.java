package com.cu.lab.example.aadesh1.hub;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;


public class Profile extends AppCompatActivity
{
    String name="", ph="", city="", pin="";
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);

        Button save;
        EditText ename, eph, ecity, epin;

        ename = findViewById(R.id.name);
        eph = findViewById(R.id.ph);
        ecity = findViewById(R.id.city);
        epin = findViewById(R.id.pin);
        save = findViewById(R.id.save);

        ename.setText(name);
        eph.setText(ph);
        ecity.setText(city);
        epin.setText(pin);
        databaseReference = FirebaseDatabase.getInstance().getReference("User").child("Profile").child(name);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                    name = ename.getText().toString();
                    ph = eph.getText().toString();
                    city = ecity.getText().toString();
                    pin = epin.getText().toString();
                    Map<String, Object> mp = new HashMap<>();
                    mp.put("User_Name", name);
                    mp.put("Phone", ph);
                    mp.put("City", city);
                    mp.put("Pin", pin);

                    databaseReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot)
                        {
                            databaseReference.setValue(mp);
                            Toast.makeText(Profile.this, "Saved", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Profile.this, MainActivity.class));

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(Profile.this, "Fail to Save..", Toast.LENGTH_SHORT).show();
                        }
                    });

                }

        });

    };

}
